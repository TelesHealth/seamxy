
# API Reference (MVP)

## POST /analyze_profile
Body: { "text": "34-year-old consultant, minimalist, under $120 per item" }
Returns: { age, lifestyle, style_tags, budget }

## POST /recommend
Body: { "fit": {"category":"chino"}, "style_tags":["minimalist"], "budget_range":[50,150] }
Returns: { results: [ { product ... total_score, checkout_url } ] }

## POST /quickbuy
Body: { "product_id": "P1" }
Returns: { "checkout_url": "https://..." }

## GET /makers
Returns: { makers: [...] }

## POST /custom-request
Body: {
  "item_type":"custom suit",
  "budget_min":500, "budget_max":900,
  "style_tags":["modern","slim"],
  "measurements":{"chest":40,"waist":32}
}
Returns: { request: {...}, matched_makers: [...] }

## POST /quote
Body: { "request_id":"R1", "maker_id":"M1", "price":780, "lead_time_days":14, "message":"..." }
Returns: { ... status: "sent" }
