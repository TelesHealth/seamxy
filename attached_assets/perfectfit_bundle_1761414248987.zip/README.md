
# PerfectFit — MVP (Retail + Bespoke)

**Stack (Option A):** Flask backend, Flutter frontend, PostgreSQL (stubbed), Stripe, OpenAI (stub parser).  
**Packaging:** Single ZIP.  
**Style:** Light minimalist.

## Run Backend (Replit)
```bash
cd backend
pip install -r requirements.txt
python app.py
```
The API runs at `http://localhost:8080/api/v1`

## Endpoints
- `POST /analyze_profile` — parse freehand text
- `POST /measurements` — save measurements (stub)
- `POST /recommend` — ranked retail results (with Quick Buy links)
- `POST /quickbuy` — returns checkout_url
- `GET /makers` — list demo makers
- `POST /custom-request` — match makers for bespoke request (RFQ)
- `POST /quote` — maker submits quote (stub)

## Run Flutter (Web for demo)
```bash
cd frontend
flutter pub get
flutter run -d chrome
```
Edit `ApiService.base` if your backend URL differs.

## Notes
- Product/maker data are mock objects for MVP; replace with live APIs.
- Payment flow is demonstrated via checkout links; integrate Stripe next.
- AI parser is a safe stub; swap with OpenAI in `services/ai_parser.py`.

© PerfectFit 2025
